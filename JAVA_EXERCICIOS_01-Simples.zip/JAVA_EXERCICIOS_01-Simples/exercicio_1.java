//Escreva um programa que imprima a mensagem "Meu nome é [seu nome]".

public class exercicio_1 {
    public static void main(String[] args) {

        System.out.print("Meu nome é Emily.");

    }
}