//Desenhe um círculo utilizando o caractere ponto (.) com raio de 5 caracteres.

public class exercicio_10 {
    public static void main(String[] args) {
        
        System.out.println("    ...");
        System.out.println(" .        .");
        System.out.println(".          .");
        System.out.println(".          .");
        System.out.println(" .        . ");
        System.out.println("    ...");
        
    }
}
