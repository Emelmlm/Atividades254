//Desenhe uma seta apontando para a direita utilizando o caractere maior que (>) com altura de 5 linhas.

public class exercicio_11 {
    public static void main(String[] args) {
        
        System.out.println(">");
        System.out.println("   >");
        System.out.println("     >");
        System.out.println("   >");
        System.out.println(">");

    }
}
