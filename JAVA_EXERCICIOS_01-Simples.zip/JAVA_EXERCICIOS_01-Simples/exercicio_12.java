/*2. Desenhe uma flecha apontando para a esquerda utilizando o caractere menor que (<) com altura de 5
linhas*/

public class exercicio_12 {
    public static void main(String[] args) {
        
        System.out.println("      <");
        System.out.println("    <");
        System.out.println(" <");
        System.out.println("    <");
        System.out.println("       <");

    }
}
