/*Desenhe um padrão de xadrez utilizando os caracteres cerquilha (#) e espaço em branco ( ) com tamanho de
8x8.*/

public class exercicio_14 {
    public static void main(String[] args) {
        
        System.out.println("# # # # #");
        System.out.println(" # # # # #");
        System.out.println("# # # # # ");
        System.out.println(" # # # # # ");
        System.out.println("# # # # # ");
        
    }
}


