// Desenhe um triângulo invertido utilizando o caractere asterisco (*) com altura de 7 linhas.

public class exercicio_15 {
    public static void main(String[] args) {
        
        System.out.println("*************");
        System.out.println(" ***********");
        System.out.println("  *********");
        System.out.println("   *******");
        System.out.println("    *****");
        System.out.println("     ***");
        System.out.println("      *");
        
    }
}
