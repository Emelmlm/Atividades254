//Escreva um programa que imprima a mensagem "A soma de 2 + 2 é igual a 4".

public class exercicio_2 {
    public static void main(String[] args) {

        System.out.println("A soma de 2 + 2 é igual a 4.");
        
    }
}
