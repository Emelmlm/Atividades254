//Escreva um programa que imprima uma linha com dez asteriscos (*) consecutivos.

import java.util.Scanner;
public class exercicio_3 {
    public static void main(String[] args) {
        int i;
        Scanner ler = new Scanner(System.in);
        
        for (i = 0; i <= 10; i++){
            System.out.print("*");
        }

        System.out.println("");
        
    }
}
