//Desenhe um quadrado vazado utilizando o caractere asterisco (*) com lado de tamanho 5.

public class exercicio_4 {
    public static void main(String[] args) {

        System.out.println("*****");
        System.out.println("*   *");
        System.out.println("*   *");
        System.out.println("*   *");
        System.out.println("*****");

    }
}
