//Desenhe um triângulo utilizando o caractere hashtag (#) com altura de 6 linhas

public class exercicio_5 {
    public static void main(String[] args) {
        
          System.out.println("     #");
          System.out.println("    ###");
          System.out.println("   #####");
          System.out.println("  #######");
          System.out.println(" #########");
          System.out.println("###########");

    }
}
