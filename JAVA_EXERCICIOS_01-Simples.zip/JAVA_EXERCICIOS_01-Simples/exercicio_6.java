//Desenhe um losango utilizando o caractere ponto (.) com largura de 7 caracteres.

public class exercicio_6 {
    public static void main(String[] args) {

        System.out.println("   .   ");
        System.out.println("  ...  ");
        System.out.println(" ..... ");
        System.out.println(".......");
        System.out.println(" ..... ");
        System.out.println("  ...  ");
        System.out.println("   .   ");

    }
}
