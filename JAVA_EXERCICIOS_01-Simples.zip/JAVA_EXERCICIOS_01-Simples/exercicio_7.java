//Desenhe uma pirâmide utilizando o caractere cifrão ($) com altura de 5 linhas.

public class exercicio_7 {
    public static void main(String[] args) {
        
        System.out.println("     $");
        System.out.println("    $$$");
        System.out.println("   $$$$$");
        System.out.println("  $$$$$$$");
        System.out.println(" $$$$$$$$$");
        
    }
}
