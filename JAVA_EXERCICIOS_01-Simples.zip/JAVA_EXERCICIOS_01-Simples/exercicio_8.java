//Desenhe uma árvore de Natal utilizando o caractere asterisco (*) com altura de 8 linhas.

public class exercicio_8 {
    public static void main(String[] args) {
        
        System.out.println("       *");
        System.out.println("      ***");
        System.out.println("     *****");
        System.out.println("    *******");
        System.out.println("   *********");
        System.out.println("  ***********");
        System.out.println(" *************");
        System.out.println("***************");
        System.out.println("      ***      ");
        System.out.println("      ***      ");

    }
}
