/*Desenhe um coração utilizando o caractere asterisco (*) e o caractere espaço em branco ( ) com altura
de 7 linhas.*/

public class exercicio_9 {
    public static void main(String[] args) {
        
        System.out.println("      **    **");
        System.out.println("   *      *      *");
        System.out.println("  *               *");
        System.out.println("   *             *");
        System.out.println("     *         *");
        System.out.println("       *     *");
        System.out.println("          *");

    }
}
